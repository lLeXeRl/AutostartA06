//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Bu3V2xqD.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/probe",
			"/script",
			"/sequence",
			"/setup"
		],
		preloads: ["/assets/index-BMbWBID9.js", "/assets/store-7amNJ7mx.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-BMbWBID9.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-B9hBZ125.js",
			"/assets/category-icon-D3qj0vFM.js",
			"/assets/rotate-ccw-gaKPLpH2.js",
			"/assets/catalog-B8F7Dfa8.js",
			"/assets/badge-P1Om7Z6Z.js",
			"/assets/setup-CsRH15FA.js",
			"/assets/scripts-Dd4ngHIo.js"
		]
	},
	"/probe": {
		filePath: "/workspace/src/routes/probe.tsx",
		children: void 0,
		preloads: [
			"/assets/probe-qTzDI1aG.js",
			"/assets/category-icon-D3qj0vFM.js",
			"/assets/rotate-ccw-gaKPLpH2.js",
			"/assets/catalog-B8F7Dfa8.js"
		]
	},
	"/script": {
		filePath: "/workspace/src/routes/script.tsx",
		children: void 0,
		preloads: [
			"/assets/script-C3e6ZPTH.js",
			"/assets/copy-block-Cn71E2Oa.js",
			"/assets/catalog-B8F7Dfa8.js",
			"/assets/scripts-Dd4ngHIo.js"
		]
	},
	"/sequence": {
		filePath: "/workspace/src/routes/sequence.tsx",
		children: void 0,
		preloads: [
			"/assets/sequence-Dhag-Ayh.js",
			"/assets/category-icon-D3qj0vFM.js",
			"/assets/catalog-B8F7Dfa8.js",
			"/assets/badge-P1Om7Z6Z.js",
			"/assets/scripts-Dd4ngHIo.js",
			"/assets/switch-DTefLa4v.js"
		]
	},
	"/setup": {
		filePath: "/workspace/src/routes/setup.tsx",
		children: void 0,
		preloads: [
			"/assets/setup-EAtMBv0G.js",
			"/assets/copy-block-Cn71E2Oa.js",
			"/assets/catalog-B8F7Dfa8.js",
			"/assets/setup-CsRH15FA.js",
			"/assets/switch-DTefLa4v.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
