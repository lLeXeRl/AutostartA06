//#region node_modules/.nitro/vite/services/ssr/assets/setup-H6RK1Yqq.js
var SETUP_STEPS = [
	{
		id: "sdaSettings",
		n: 1,
		title: "Поставить Settings через SDA",
		lead: "На стоковом ГУ A06 нет нормальных «Настроек разработчика». Их открывает приложение Settings из портала SDA.",
		body: [
			"На ГУ откройте портал SDA (штатный канал установки).",
			"Найдите и установите приложение Settings. Без него пункты отладки часто недоступны.",
			"Альтернатива — инженерное меню, но для автозапуска достаточно Settings."
		]
	},
	{
		id: "devMode",
		n: 2,
		title: "Режим разработчика",
		lead: "Как на обычном Android, только путь может называться чуть иначе в зависимости от прошивки.",
		body: [
			"Settings → О системе → семь раз нажмите «Номер сборки», пока не появится «Вы стали разработчиком».",
			"Settings → Система → Для разработчиков.",
			"Включите: USB-отладка, установка из неизвестных источников, Wireless debugging."
		]
	},
	{
		id: "wirelessAdb",
		n: 3,
		title: "Wireless debugging",
		lead: "На A06 надёжнее Wi-Fi ADB: USB-отладка в Settings часто ведёт себя странно.",
		body: [
			"Ноутбук и ГУ — в одной Wi-Fi сети. VPN и прокси выключите.",
			"Wireless debugging → «Сопряжение с помощью кода». Запомните IP, порт и 6-значный код. Окно не закрывайте.",
			"На компьютере должны быть Android Platform Tools (adb)."
		],
		commands: [
			"adb pair <IP>:<порт_сопряжения> <код>",
			"adb connect <IP>:<порт_подключения>",
			"adb devices -l"
		]
	},
	{
		id: "caedc",
		n: 4,
		title: "Обойти проверку CAEDC",
		lead: "До перезагрузки ГУ верификатор пакетов мешает pm install. Эти свойства сбрасываются после ребута.",
		body: [
			"Подключившись по ADB, выполните две команды setprop.",
			"Проверьте, что обе вернули 1.",
			"После этого можно ставить APK: MacroDroid, Навигатор, Музыку."
		],
		commands: [
			"adb -s $SER shell setprop vecentek.model 1",
			"adb -s $SER shell setprop debug.ro.debuggable 1",
			"adb -s $SER shell getprop vecentek.model",
			"adb -s $SER shell getprop debug.ro.debuggable"
		],
		warn: "Команды действуют до перезагрузки ГУ. Перед каждой новой установкой APK их нужно повторить."
	},
	{
		id: "helperInstalled",
		n: 5,
		title: "Поставить движок автозапуска",
		lead: "Само веб-приложение на ГУ другие программы не откроет. Нужен MacroDroid (рекомендуем) или AutoStart.",
		body: [
			"Скачайте APK MacroDroid на ноутбук (официальный сайт или проверенный архив).",
			"Залейте и установите через ADB. Флаг -g выдаёт базовые разрешения сразу.",
			"Приложение должно появиться в списке на ГУ."
		],
		commands: [
			"adb -s $SER push MacroDroid.apk /data/local/tmp/macrodroid.apk",
			"adb -s $SER shell pm install -r -g /data/local/tmp/macrodroid.apk",
			"adb -s $SER shell rm -f /data/local/tmp/macrodroid.apk"
		]
	},
	{
		id: "permissions",
		n: 6,
		title: "Права и автозапуск",
		lead: "Китайские прошивки убивают фоновые приложения. Без белого списка макрос не доживёт до конца загрузки.",
		body: [
			"В MacroDroid разрешите автозапуск, работу в фоне и (если спросит) показ поверх окон.",
			"Отключите оптимизацию батареи для MacroDroid.",
			"Если в Settings есть «Автозапуск» / Startup manager — добавьте MacroDroid в список."
		],
		commands: [
			"adb -s $SER shell dumpsys deviceidle whitelist +com.arlosoft.macrodroid",
			"adb -s $SER shell cmd appops set com.arlosoft.macrodroid RUN_IN_BACKGROUND allow",
			"adb -s $SER shell cmd appops set com.arlosoft.macrodroid SYSTEM_ALERT_WINDOW allow"
		]
	},
	{
		id: "macroBuilt",
		n: 7,
		title: "Собрать макрос по сценарию",
		lead: "Откройте вкладку «Скрипт» — там готовая последовательность нажатий под ваш профиль.",
		body: [
			"Триггер: «Загрузка устройства завершена».",
			"Первое действие — пауза (задержка после включения ГУ).",
			"Дальше: запуск приложений с паузами между ними, как в сценарии.",
			"Сохраните макрос и проверьте тестовым запуском из приложения, затем — реальным выключением/включением ГУ."
		]
	}
];
//#endregion
export { SETUP_STEPS as t };
