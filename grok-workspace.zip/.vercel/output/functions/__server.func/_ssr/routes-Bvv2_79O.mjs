import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { b as ArrowRight, c as Play, o as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as useLaunchStore, i as totalReadySec, o as cn, r as enabledSteps } from "./router-DVtL4Mlj.mjs";
import { a as Card, c as CardHeader, l as CardTitle, o as CardContent, s as CardDescription, t as Button, u as resolveStep } from "./catalog-8gw6UY3Y.mjs";
import { t as CategoryIcon } from "./category-icon-BnpxTKRP.mjs";
import { t as Badge } from "./badge-DwB_zBrh.mjs";
import { t as SETUP_STEPS } from "./setup-H6RK1Yqq.mjs";
import { c as methodLabel } from "./scripts-BfjAIM6-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Bvv2_79O.js
var import_jsx_runtime = require_jsx_runtime();
function SequenceTimeline({ profile, activeIndex = -1, compact = false }) {
	const steps = enabledSteps(profile);
	if (steps.length === 0) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-muted-foreground",
		children: "Сценарий пуст. Добавьте приложения во вкладке «Сценарий»."
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
		className: cn("flex flex-col", compact ? "gap-2" : "gap-3"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
			className: "flex items-center gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "flex size-9 shrink-0 items-center justify-center rounded-md border border-border bg-muted text-xs font-medium tabular-nums text-muted-foreground",
				children: [profile.bootDelaySec, "с"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm font-medium",
				children: "Ожидание готовности ГУ"
			}), !compact && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Лаунчер Changan поднимается не сразу. Не ставьте меньше 15 с."
			})] })]
		}), steps.map((step, index) => {
			const app = resolveStep(step);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: cn("flex size-9 shrink-0 items-center justify-center rounded-md border", index === activeIndex ? "border-primary bg-primary text-primary-foreground" : "border-border bg-card text-foreground"),
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryIcon, {
						category: app.category,
						className: "size-4"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "truncate text-sm font-medium",
						children: app.name
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "truncate text-xs text-muted-foreground",
						children: [step.delaySec > 0 ? `пауза ${step.delaySec} с · ` : "", app.packageName]
					})]
				})]
			}, step.id);
		})]
	});
}
function Home() {
	const profile = useLaunchStore((s) => s.profile);
	const setup = useLaunchStore((s) => s.setup);
	const resetAll = useLaunchStore((s) => s.resetAll);
	const done = SETUP_STEPS.filter((step) => setup[step.id]).length;
	const ready = totalReadySec(profile);
	const apps = enabledSteps(profile).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-3 md:flex-row md:items-end md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Пульт"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-medium tracking-tight md:text-4xl",
						children: "При включении ГУ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-muted-foreground",
						children: "Соберите порядок запуска, поставьте MacroDroid на Qiyuan A06 и выгрузите готовый макрос. Само приложение на телефоне машину не управляет — оно готовит сценарий."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/probe",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), "Проба запуска"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: "/sequence",
							children: ["Править сценарий", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, {})]
						})
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 md:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Готовность" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "text-3xl tabular-nums tracking-tight",
						children: [ready, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-1 text-base font-medium text-muted-foreground",
							children: "с"
						})]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "pt-0 text-sm text-muted-foreground",
						children: "от ACC до последнего приложения"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "В сценарии" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, {
						className: "text-3xl tabular-nums tracking-tight",
						children: apps
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "pt-0 text-sm text-muted-foreground",
						children: [
							"профиль «",
							profile.name,
							"» · ",
							methodLabel(profile.method)
						]
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Установка на ГУ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardTitle, {
						className: "text-3xl tabular-nums tracking-tight",
						children: [done, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "ml-1 text-base font-medium text-muted-foreground",
							children: ["/ ", SETUP_STEPS.length]
						})]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
						className: "pt-0",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							tone: done === SETUP_STEPS.length ? "ok" : "muted",
							children: done === SETUP_STEPS.length ? "Готово к бою" : "Есть шаги"
						})
					})] })
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-4 lg:grid-cols-[1.2fr_0.8fr]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Следующий запуск" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Так поведут себя приложения после включения головного устройства." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SequenceTimeline, { profile }) })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Чеклист A06" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Отмечайте шаги во вкладке «Установка»." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex flex-col gap-2",
					children: [SETUP_STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-3 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: setup[step.id] ? "size-2 rounded-full bg-ok" : "size-2 rounded-full bg-border" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: setup[step.id] ? "text-foreground" : "text-muted-foreground",
							children: step.title
						})]
					}, step.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						className: "mt-3",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/setup",
							children: "Открыть установку"
						})
					})]
				})] })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex justify-end",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					variant: "ghost",
					size: "sm",
					onClick: () => {
						if (window.confirm("Сбросить сценарий и чеклист?")) resetAll();
					},
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Сбросить всё"]
				})
			})
		]
	});
}
//#endregion
export { Home as component };
