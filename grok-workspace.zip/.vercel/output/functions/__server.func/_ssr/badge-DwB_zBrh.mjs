import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { o as cn } from "./router-DVtL4Mlj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/badge-DwB_zBrh.js
var import_jsx_runtime = require_jsx_runtime();
function Badge({ className, tone = "muted", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium tabular-nums", tone === "muted" && "bg-muted text-muted-foreground", tone === "ok" && "bg-ok/15 text-ok", tone === "warn" && "bg-warn/15 text-warn", tone === "line" && "border border-border text-muted-foreground", className),
		...props
	});
}
//#endregion
export { Badge as t };
