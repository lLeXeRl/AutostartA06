import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as useLaunchStore } from "./router-DVtL4Mlj.mjs";
import { a as Card, o as CardContent, t as Button } from "./catalog-8gw6UY3Y.mjs";
import { t as SETUP_STEPS } from "./setup-H6RK1Yqq.mjs";
import { t as CopyBlock } from "./copy-block-Da5qRu5c.mjs";
import { t as Switch } from "./switch-DTVeZ_M0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/setup-B5f851xQ.js
var import_jsx_runtime = require_jsx_runtime();
function SetupPage() {
	const setup = useLaunchStore((s) => s.setup);
	const toggleSetup = useLaunchStore((s) => s.toggleSetup);
	const done = SETUP_STEPS.filter((step) => setup[step.id]).length;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Установка"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-medium tracking-tight",
					children: "Семь шагов на ГУ A06"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Прошивка вроде 1.6.0, портал SDA, Wi-Fi ADB и обход CAEDC. Отмечайте сделанное — прогресс останется в этом браузере."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-sm tabular-nums text-muted-foreground",
					children: [
						done,
						" из ",
						SETUP_STEPS.length
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "flex flex-col gap-4",
				children: SETUP_STEPS.map((step) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
					className: "flex flex-col gap-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-start gap-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "flex size-9 shrink-0 items-center justify-center rounded-md border border-border bg-muted text-sm font-medium tabular-nums",
							children: step.n
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "min-w-0 flex-1",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-start justify-between gap-3",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "font-medium",
										children: step.title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted-foreground",
										children: step.lead
									})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										checked: setup[step.id],
										onCheckedChange: () => toggleSetup(step.id),
										"aria-label": `${step.title}: сделано`
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
									className: "mt-3 flex flex-col gap-1.5 text-sm text-foreground",
									children: step.body.map((line) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
										className: "pl-0",
										children: line
									}, line))
								}),
								step.warn ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 text-sm text-warn",
									children: step.warn
								}) : null
							]
						})]
					}), step.commands ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, {
						label: "Команды",
						text: step.commands.join("\n") + "\n"
					}) : null]
				}) }) }, step.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/script",
						children: "Открыть готовый скрипт"
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					asChild: true,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/probe",
						children: "Прогнать пробу"
					})
				})]
			})
		]
	});
}
//#endregion
export { SetupPage as component };
