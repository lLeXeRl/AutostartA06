import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { _ as ChevronUp, i as Trash2, s as Plus, t as X, v as ChevronDown } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as DialogTrigger$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as useLaunchStore, n as PRESETS, o as cn } from "./router-DVtL4Mlj.mjs";
import { a as Card, c as CardHeader, i as CATEGORY_ORDER, l as CardTitle, n as CATALOG, o as CardContent, r as CATEGORY_LABEL, s as CardDescription, t as Button, u as resolveStep } from "./catalog-8gw6UY3Y.mjs";
import { t as CategoryIcon } from "./category-icon-BnpxTKRP.mjs";
import { t as Badge } from "./badge-DwB_zBrh.mjs";
import { c as methodLabel } from "./scripts-BfjAIM6-.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider$1 } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { t as Switch } from "./switch-DTVeZ_M0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/sequence-B871YdE2.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogTrigger = DialogTrigger$1;
function DialogContent({ className, children, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, { className: "fixed inset-0 z-50 bg-background/70 data-[state=open]:animate-none" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
		className: cn("fixed top-1/2 left-1/2 z-50 w-[min(100%-1.5rem,40rem)] max-h-[min(88vh,40rem)] -translate-x-1/2 -translate-y-1/2 overflow-y-auto rounded-xl border border-border bg-card p-5 shadow-lg", className),
		...props,
		children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "ghost",
				size: "icon",
				className: "absolute top-3 right-3 size-9",
				"aria-label": "Закрыть",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, {})
			})
		})]
	})] });
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("mb-4 pr-10", className),
		...props
	});
}
function DialogTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
		className: cn("text-lg font-medium tracking-tight", className),
		...props
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
		className: cn("mt-1 text-sm text-muted-foreground", className),
		...props
	});
}
function Input({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
		className: cn("h-11 w-full rounded-sm border border-border bg-background px-3 text-sm text-foreground placeholder:text-faint transition-[border-color,box-shadow] duration-150", "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring", className),
		...props
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
		className: cn("text-sm font-medium text-foreground", className),
		...props
	});
}
function Slider({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider$1, {
		className: cn("relative flex w-full touch-none items-center select-none", className),
		...props,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
			className: "relative h-1.5 w-full grow overflow-hidden rounded-full bg-muted",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full bg-primary" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, { className: "block size-4 rounded-full border border-border bg-primary shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring" })]
	});
}
function SequencePage() {
	const profile = useLaunchStore((s) => s.profile);
	const setName = useLaunchStore((s) => s.setName);
	const setBootDelay = useLaunchStore((s) => s.setBootDelay);
	const setMethod = useLaunchStore((s) => s.setMethod);
	const applyPreset = useLaunchStore((s) => s.applyPreset);
	const addStep = useLaunchStore((s) => s.addStep);
	const updateStep = useLaunchStore((s) => s.updateStep);
	const removeStep = useLaunchStore((s) => s.removeStep);
	const moveStep = useLaunchStore((s) => s.moveStep);
	const [open, setOpen] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Сценарий"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 text-3xl font-medium tracking-tight",
					children: "Порядок запуска"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Задержка после включения — общая. Пауза у приложения срабатывает перед ним. Навигатор всегда ставьте первым."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex flex-wrap gap-2",
				children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: profile.name === preset.name ? "default" : "outline",
					size: "sm",
					onClick: () => applyPreset(preset.id),
					children: preset.name
				}, preset.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: "Профиль" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardDescription, { children: "Имя попадёт в макрос и в имя файла скрипта." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "grid gap-5 md:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
							htmlFor: "profile-name",
							children: "Название"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							id: "profile-name",
							value: profile.name,
							onChange: (e) => setName(e.target.value),
							maxLength: 40
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Движок на ГУ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "flex flex-wrap gap-2",
							children: [
								"macrodroid",
								"autostart",
								"tasker"
							].map((method) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								type: "button",
								size: "sm",
								variant: profile.method === method ? "default" : "outline",
								onClick: () => setMethod(method),
								children: methodLabel(method)
							}, method))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2 md:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Пауза после включения ГУ" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "text-sm tabular-nums text-muted-foreground",
								children: [profile.bootDelaySec, " с"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
							min: 10,
							max: 60,
							step: 1,
							value: [profile.bootDelaySec],
							onValueChange: (v) => setBootDelay(v[0] ?? 25)
						})]
					})
				]
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-base font-medium",
					children: "Приложения"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
					open,
					onOpenChange: setOpen,
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Добавить"]
						})
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Каталог для A06" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Пакеты проверены на типичных APK. Своё приложение — внизу." })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AddAppForm, {
						existing: profile.steps.map((s) => s.appId),
						onAdd: (payload) => {
							addStep(payload);
							setOpen(false);
						}
					})] })]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "flex flex-col gap-3",
				children: profile.steps.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
					className: "text-sm text-muted-foreground",
					children: "Список пуст. Добавьте хотя бы навигатор."
				}) }) : profile.steps.map((step, index) => {
					const app = resolveStep(step);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
						className: "flex flex-col gap-4",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-start gap-3",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-md border border-border bg-muted",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryIcon, { category: app.category })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "min-w-0 flex-1",
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex flex-wrap items-center gap-2",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "font-medium",
													children: app.name
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													tone: "line",
													children: CATEGORY_LABEL[app.category]
												}),
												app.splitOk ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
													tone: "muted",
													children: "split ok"
												}) : null
											]
										}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-0.5 truncate font-mono text-xs text-muted-foreground",
											children: app.packageName
										})]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Switch, {
										checked: step.enabled,
										onCheckedChange: (checked) => updateStep(step.id, { enabled: checked }),
										"aria-label": "В сценарии"
									})
								]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Пауза перед запуском" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
										className: "text-sm tabular-nums text-muted-foreground",
										children: [step.delaySec, " с"]
									})]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slider, {
									min: 0,
									max: 20,
									step: 1,
									value: [step.delaySec],
									onValueChange: (v) => updateStep(step.id, { delaySec: v[0] ?? 0 })
								})]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-wrap gap-2",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: "outline",
										size: "sm",
										disabled: index === 0,
										onClick: () => moveStep(step.id, -1),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronUp, {}), "Выше"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: "outline",
										size: "sm",
										disabled: index === profile.steps.length - 1,
										onClick: () => moveStep(step.id, 1),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronDown, {}), "Ниже"]
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										type: "button",
										variant: "ghost",
										size: "sm",
										className: "ml-auto text-destructive",
										onClick: () => removeStep(step.id),
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Убрать"]
									})
								]
							})
						]
					}) }) }, step.id);
				})
			})
		]
	});
}
function AddAppForm({ existing, onAdd }) {
	const [query, setQuery] = (0, import_react.useState)("");
	const [customName, setCustomName] = (0, import_react.useState)("");
	const [customPackage, setCustomPackage] = (0, import_react.useState)("");
	const grouped = (0, import_react.useMemo)(() => {
		const q = query.trim().toLowerCase();
		return CATEGORY_ORDER.map((category) => ({
			category,
			apps: CATALOG.filter((app) => {
				if (app.category !== category) return false;
				if (!q) return true;
				return app.name.toLowerCase().includes(q) || app.packageName.toLowerCase().includes(q);
			})
		})).filter((g) => g.apps.length > 0);
	}, [query]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				placeholder: "Поиск по имени или пакету",
				value: query,
				onChange: (e) => setQuery(e.target.value)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex max-h-72 flex-col gap-4 overflow-y-auto pr-1",
				children: grouped.map((group) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: CATEGORY_LABEL[group.category]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "flex flex-col gap-1",
					children: group.apps.map((app) => {
						const used = existing.includes(app.id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							disabled: used,
							onClick: () => onAdd({
								appId: app.id,
								delaySec: app.category === "nav" ? 0 : 5,
								enabled: true
							}),
							className: "flex w-full items-start gap-3 rounded-md px-2 py-2 text-left hover:bg-muted disabled:opacity-40",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryIcon, {
								category: app.category,
								className: "mt-0.5"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "min-w-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-sm font-medium",
									children: app.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "block text-xs text-muted-foreground",
									children: [used ? "Уже в сценарии · " : "", app.blurb]
								})]
							})]
						}) }, app.id);
					})
				})] }, group.category))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-2 rounded-md border border-border p-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Свой пакет"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "Имя, как на ГУ",
						value: customName,
						onChange: (e) => setCustomName(e.target.value)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						placeholder: "com.example.app",
						value: customPackage,
						onChange: (e) => setCustomPackage(e.target.value),
						className: "font-mono"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						type: "button",
						variant: "outline",
						disabled: !customPackage.trim(),
						onClick: () => onAdd({
							appId: `custom:${customPackage.trim()}`,
							delaySec: 5,
							enabled: true,
							customName: customName.trim() || customPackage.trim(),
							customPackage: customPackage.trim()
						}),
						children: "Добавить пакет"
					})
				]
			})
		]
	});
}
//#endregion
export { SequencePage as component };
