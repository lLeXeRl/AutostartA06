import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { c as Play, d as MessageCircle, g as Compass, n as Wrench, u as Music } from "../_libs/lucide-react.mjs";
import { o as cn } from "./router-DVtL4Mlj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/category-icon-BnpxTKRP.js
var import_jsx_runtime = require_jsx_runtime();
var ICONS = {
	nav: Compass,
	media: Music,
	video: Play,
	chat: MessageCircle,
	tool: Wrench
};
function CategoryIcon({ category, className }) {
	const Icon = ICONS[category];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: cn("size-4", className) });
}
//#endregion
export { CategoryIcon as t };
