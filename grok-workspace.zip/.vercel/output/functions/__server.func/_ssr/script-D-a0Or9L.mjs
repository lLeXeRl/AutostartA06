import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as useLaunchStore, r as enabledSteps } from "./router-DVtL4Mlj.mjs";
import { a as Card, c as CardHeader, l as CardTitle, o as CardContent, s as CardDescription, t as Button } from "./catalog-8gw6UY3Y.mjs";
import { a as buildUnixScript, c as methodLabel, i as buildTestCommands, n as buildMacrodroidGuide, o as buildWindowsScript, r as buildTaskerGuide, t as buildAutostartGuide } from "./scripts-BfjAIM6-.mjs";
import { t as CopyBlock } from "./copy-block-Da5qRu5c.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/script-D-a0Or9L.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ScriptPage() {
	const profile = useLaunchStore((s) => s.profile);
	const [tab, setTab] = (0, import_react.useState)("guide");
	const slug = profile.name.toLowerCase().replace(/[^a-z0-9а-яё]+/gi, "-").replace(/^-|-$/g, "") || "profile";
	const guide = profile.method === "autostart" ? buildAutostartGuide(profile) : profile.method === "tasker" ? buildTaskerGuide(profile) : buildMacrodroidGuide(profile);
	const empty = enabledSteps(profile).length === 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
					children: "Скрипт"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-1 text-3xl font-medium tracking-tight",
					children: [
						"Выгрузка «",
						profile.name,
						"»"
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-2 max-w-2xl text-sm text-muted-foreground",
					children: "Макрос собирается руками на ГУ по инструкции. ADB-скрипт — чтобы проверить запуск сейчас, не дожидаясь следующего включения."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Card, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardTitle, { children: methodLabel(profile.method) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardDescription, { children: [
				"Движок меняется в сценарии. Сейчас активен ",
				methodLabel(profile.method),
				"."
			] })] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CardContent, {
				className: "flex flex-wrap gap-2",
				children: [
					["guide", "Инструкция"],
					["unix", "ADB · Mac/Linux"],
					["win", "ADB · Windows"],
					["test", "Проверка сразу"]
				].map(([id, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					size: "sm",
					variant: tab === id ? "default" : "outline",
					onClick: () => setTab(id),
					children: label
				}, id))
			})] }),
			empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-muted-foreground",
				children: "В сценарии нет включённых приложений — добавлять нечего."
			}) : null,
			tab === "guide" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, {
				label: `Инструкция · ${methodLabel(profile.method)}`,
				text: guide
			}) : null,
			tab === "unix" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, {
				label: "a06-start.sh",
				filename: `a06-start-${slug}.sh`,
				text: buildUnixScript(profile)
			}) : null,
			tab === "win" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, {
				label: "a06-start.bat",
				filename: `a06-start-${slug}.bat`,
				text: buildWindowsScript(profile)
			}) : null,
			tab === "test" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CopyBlock, {
				label: "Команды без длинной паузы",
				text: buildTestCommands(profile)
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-faint",
				children: "Установка APK и setprop — на ваш риск. CAEDC сбрасывается после ребута ГУ. Не отключайте системные пакеты Changan."
			})
		]
	});
}
//#endregion
export { ScriptPage as component };
