import { i as __toESM } from "../_runtime.mjs";
import { o as require_jsx_runtime, s as require_react } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { c as Play, l as Pause, o as RotateCcw } from "../_libs/lucide-react.mjs";
import { a as useLaunchStore, i as totalReadySec, o as cn, r as enabledSteps } from "./router-DVtL4Mlj.mjs";
import { a as Card, o as CardContent, t as Button, u as resolveStep } from "./catalog-8gw6UY3Y.mjs";
import { t as CategoryIcon } from "./category-icon-BnpxTKRP.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/probe-DwsJP9Nj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var SIM_SPEED = 8;
function ProbePage() {
	const profile = useLaunchStore((s) => s.profile);
	const steps = enabledSteps(profile);
	const total = totalReadySec(profile);
	const events = (0, import_react.useMemo)(() => {
		const list = [
			{
				at: 0,
				label: "ACC ON"
			},
			{
				at: 2,
				label: "Загрузка лаунчера"
			},
			{
				at: profile.bootDelaySec,
				label: "ГУ готово"
			}
		];
		let t = profile.bootDelaySec;
		for (const step of steps) {
			t += step.delaySec;
			list.push({
				at: t,
				label: resolveStep(step).name
			});
		}
		return list;
	}, [profile.bootDelaySec, steps]);
	const [machine, setMachine] = (0, import_react.useState)("idle");
	const [elapsed, setElapsed] = (0, import_react.useState)(0);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const elapsedRef = (0, import_react.useRef)(0);
	(0, import_react.useEffect)(() => {
		if (machine !== "running" || paused) return;
		const id = window.setInterval(() => {
			elapsedRef.current += .1 * SIM_SPEED;
			const sec = elapsedRef.current;
			if (sec >= total + 1.2) {
				setMachine("ready");
				setElapsed(total);
				elapsedRef.current = total;
				return;
			}
			setElapsed(sec);
		}, 100);
		return () => window.clearInterval(id);
	}, [
		machine,
		paused,
		total
	]);
	function start() {
		elapsedRef.current = 0;
		setElapsed(0);
		setPaused(false);
		setMachine("running");
	}
	function reset() {
		elapsedRef.current = 0;
		setElapsed(0);
		setPaused(false);
		setMachine("idle");
	}
	const view = machine === "idle" ? "idle" : machine === "ready" ? "ready" : elapsed < 1.2 ? "acc" : elapsed < profile.bootDelaySec ? "boot" : "run";
	let activeAppIndex = -1;
	if (view === "run" || view === "ready") {
		let t = profile.bootDelaySec;
		for (let i = 0; i < steps.length; i += 1) {
			t += steps[i].delaySec;
			if (elapsed >= t) activeAppIndex = i;
		}
	}
	const shownApp = activeAppIndex >= 0 ? resolveStep(steps[activeAppIndex]) : null;
	const progress = total === 0 ? 0 : Math.min(1, elapsed / Math.max(total, .01));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-3 md:flex-row md:items-end md:justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium tracking-wide text-muted-foreground uppercase",
						children: "Проба"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-1 text-3xl font-medium tracking-tight",
						children: "Включение ГУ"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 max-w-xl text-sm text-muted-foreground",
						children: "Это ускоренная модель сценария (×8), не живой ADB. Нужна, чтобы поймать слишком короткие паузы до поездки."
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap gap-2",
					children: [machine === "idle" || machine === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: start,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}), machine === "ready" ? "Ещё раз" : "Зажигание"]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "outline",
						onClick: () => setPaused((v) => !v),
						children: [paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, {}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, {}), paused ? "Дальше" : "Пауза"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						onClick: reset,
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, {}), "Сброс"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mx-auto w-full max-w-3xl",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-3 md:p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between px-2 pb-3 text-xs tracking-wide text-muted-foreground uppercase",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Qiyuan A06 · 15.6" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn(view === "idle" ? "text-faint" : "text-ok"),
							children: view === "idle" ? "OFF" : view === "ready" ? "READY" : "ACC"
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative aspect-video overflow-hidden rounded-lg border border-border bg-background",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center",
							children: [
								view === "idle" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "ГУ выключено"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-faint",
									children: "Нажмите «Зажигание»"
								})] }) : null,
								view === "acc" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-medium tracking-tight",
									children: "ACC"
								}) : null,
								view === "boot" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-muted-foreground",
									children: "Загрузка системы"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "font-mono text-2xl tabular-nums",
									children: [Math.max(0, Math.ceil(profile.bootDelaySec - elapsed)), "с"]
								})] }) : null,
								view === "run" && shownApp ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "flex size-14 items-center justify-center rounded-md border border-border bg-card",
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CategoryIcon, {
											category: shownApp.category,
											className: "size-6"
										})
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-lg font-medium tracking-tight",
										children: shownApp.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs text-muted-foreground",
										children: shownApp.packageName
									})
								] }) : null,
								view === "ready" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-lg font-medium tracking-tight",
									children: "Сценарий выполнен"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "text-sm text-muted-foreground",
									children: [
										steps.length,
										" прил. за ",
										total,
										" с"
									]
								})] }) : null
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "absolute inset-x-0 bottom-0 h-1 bg-muted",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "h-full bg-primary",
								style: { width: `${progress * 100}%` }
							})
						})]
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Card, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CardContent, {
				className: "flex flex-col gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Таймлайн"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "font-mono text-sm tabular-nums text-muted-foreground",
						children: [
							elapsed.toFixed(1),
							" / ",
							total,
							" с"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
					className: "flex flex-col gap-2",
					children: events.map((event) => {
						const reached = elapsed >= event.at && machine !== "idle";
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: cn("flex items-center justify-between gap-3 text-sm", reached ? "text-foreground" : "text-muted-foreground"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: event.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "font-mono text-xs tabular-nums",
								children: [event.at, "с"]
							})]
						}, `${event.at}-${event.label}`);
					})
				})]
			}) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				asChild: true,
				className: "self-start",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/sequence",
					children: "Вернуться к сценарию"
				})
			})
		]
	});
}
//#endregion
export { ProbePage as component };
