import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { o as cn } from "./router-DVtL4Mlj.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/catalog-8gw6UY3Y.js
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-sm text-sm font-medium transition-[opacity,transform,background-color,color] duration-150 ease-out disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground hover:opacity-90",
			outline: "border border-border bg-transparent text-foreground hover:bg-muted",
			ghost: "text-foreground hover:bg-muted",
			subtle: "bg-muted text-foreground hover:bg-border",
			destructive: "bg-destructive text-primary-foreground hover:opacity-90"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 px-3 text-sm",
			lg: "h-12 px-5",
			icon: "size-11"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
function Button({ className, variant, size, asChild = false, type = "button", ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		...asChild ? props : {
			type,
			...props
		}
	});
}
function Card({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("rounded-xl border border-border bg-card text-card-foreground shadow-[var(--shadow-panel)]", className),
		...props
	});
}
function CardHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1 p-5 pb-0", className),
		...props
	});
}
function CardTitle({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
		className: cn("text-base font-medium tracking-tight", className),
		...props
	});
}
function CardDescription({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: cn("text-sm text-muted-foreground", className),
		...props
	});
}
function CardContent({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("p-5", className),
		...props
	});
}
var CATEGORY_LABEL = {
	nav: "Навигация",
	media: "Музыка",
	video: "Видео",
	chat: "Связь",
	tool: "Сервис"
};
var CATALOG = [
	{
		id: "yandex-navi",
		name: "Яндекс Навигатор",
		packageName: "ru.yandex.yandexnavi",
		category: "nav",
		blurb: "Основной сценарий на A06. Ставьте первым — карта должна открыться до музыки.",
		splitOk: true
	},
	{
		id: "dgis",
		name: "2ГИС",
		packageName: "ru.dublgis.dgismobile",
		category: "nav",
		blurb: "Офлайн-карты и пробки. Хорошая замена, если Навигатор капризничает.",
		splitOk: true
	},
	{
		id: "yandex-maps",
		name: "Яндекс Карты",
		packageName: "ru.yandex.yandexmaps",
		category: "nav",
		blurb: "Поиск мест и пробки. На ГУ обычно слабее Навигатора.",
		splitOk: true
	},
	{
		id: "gmaps",
		name: "Google Maps",
		packageName: "com.google.android.apps.maps",
		category: "nav",
		blurb: "Нужны сервисы Google. На стоковом A06 часто отсутствуют.",
		splitOk: true
	},
	{
		id: "waze",
		name: "Waze",
		packageName: "com.waze",
		category: "nav",
		blurb: "Народные пробки. Имеет смысл как второй навигатор.",
		splitOk: true
	},
	{
		id: "yandex-music",
		name: "Яндекс Музыка",
		packageName: "ru.yandex.music",
		category: "media",
		blurb: "Типичная пара к навигатору. Запускайте с паузой 4–8 с.",
		splitOk: true
	},
	{
		id: "spotify",
		name: "Spotify",
		packageName: "com.spotify.music",
		category: "media",
		blurb: "Нужен аккаунт и сеть. На ГУ лучше фиксировать качество заранее.",
		splitOk: true
	},
	{
		id: "yt-music",
		name: "YouTube Music",
		packageName: "com.google.android.apps.youtube.music",
		category: "media",
		blurb: "Если на ГУ уже есть сервисы Google.",
		splitOk: true
	},
	{
		id: "fermata",
		name: "Fermata Auto",
		packageName: "me.aap.fermata.auto",
		category: "media",
		blurb: "Локальный плеер без рекламы. Удобен в дальней дороге.",
		splitOk: true
	},
	{
		id: "newpipe",
		name: "NewPipe",
		packageName: "org.schabi.newpipe",
		category: "video",
		blurb: "YouTube без официального клиента. Часто ставят через SDA/ADB.",
		splitOk: true
	},
	{
		id: "youtube",
		name: "YouTube",
		packageName: "com.google.android.youtube",
		category: "video",
		blurb: "Официальный клиент. На A06 может требовать GMS.",
		splitOk: true
	},
	{
		id: "vk",
		name: "VK",
		packageName: "com.vkontakte.android",
		category: "video",
		blurb: "VK Видео в разделении экрана с навигатором — частый вечерний сценарий.",
		splitOk: true
	},
	{
		id: "ivi",
		name: "IVI",
		packageName: "ru.ivi.client",
		category: "video",
		blurb: "Фильмы на стоянке. В движение лучше не ставить первым.",
		splitOk: false
	},
	{
		id: "telegram",
		name: "Telegram",
		packageName: "org.telegram.messenger",
		category: "chat",
		blurb: "Уведомления после навигатора. Не открывайте поверх карты без паузы.",
		splitOk: false
	},
	{
		id: "whatsapp",
		name: "WhatsApp",
		packageName: "com.whatsapp",
		category: "chat",
		blurb: "Только если реально нужен в машине. Иначе мешает запуску.",
		splitOk: false
	},
	{
		id: "ya-browser",
		name: "Яндекс Браузер",
		packageName: "com.yandex.browser",
		category: "tool",
		blurb: "Запасной способ открыть веб-сервисы, если APK не ставится.",
		splitOk: true
	},
	{
		id: "ya-go",
		name: "Яндекс Go",
		packageName: "ru.yandex.taxi",
		category: "tool",
		blurb: "Такси и доставка. В автозапуск обычно не кладут.",
		splitOk: false
	},
	{
		id: "chrome",
		name: "Chrome",
		packageName: "com.android.chrome",
		category: "tool",
		blurb: "На стоке A06 может отсутствовать.",
		splitOk: true
	},
	{
		id: "macrodroid",
		name: "MacroDroid",
		packageName: "com.arlosoft.macrodroid",
		category: "tool",
		blurb: "Рекомендуемый движок автозапуска. Сам себя в сценарий не ставьте.",
		splitOk: false
	},
	{
		id: "autostart",
		name: "AutoStart",
		packageName: "com.autostart",
		category: "tool",
		blurb: "Простой автозапуск без макросов. Меньше гибкости, чем MacroDroid.",
		splitOk: false
	}
];
function getCatalogApp(id) {
	return CATALOG.find((app) => app.id === id);
}
function resolveStep(step) {
	if (step.customPackage) return {
		name: step.customName?.trim() || step.customPackage,
		packageName: step.customPackage.trim(),
		category: "tool",
		splitOk: true
	};
	const app = getCatalogApp(step.appId);
	if (app) return {
		name: app.name,
		packageName: app.packageName,
		category: app.category,
		splitOk: app.splitOk
	};
	return {
		name: "Неизвестное приложение",
		packageName: step.appId,
		category: "tool",
		splitOk: false
	};
}
var CATEGORY_ORDER = [
	"nav",
	"media",
	"video",
	"chat",
	"tool"
];
//#endregion
export { Card as a, CardHeader as c, CATEGORY_ORDER as i, CardTitle as l, CATALOG as n, CardContent as o, CATEGORY_LABEL as r, CardDescription as s, Button as t, resolveStep as u };
