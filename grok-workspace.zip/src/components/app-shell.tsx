import { Link, useRouterState } from "@tanstack/react-router";
import { Gauge, ListOrdered, Terminal, Wrench } from "lucide-react";
import type { ReactNode } from "react";
import { BrandMark } from "./brand-mark";
import { cn } from "@/lib/utils";
import { useLaunchStore, useRehydrateStore } from "@/lib/store";

const NAV = [
  { to: "/", label: "Пульт", icon: Gauge },
  { to: "/sequence", label: "Сценарий", icon: ListOrdered },
  { to: "/setup", label: "Установка", icon: Wrench },
  { to: "/script", label: "Скрипт", icon: Terminal },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  useRehydrateStore();
  const profileName = useLaunchStore((s) => s.profile.name);

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <div className="mx-auto flex min-h-dvh max-w-6xl">
        <aside className="sticky top-0 hidden h-dvh w-56 shrink-0 flex-col border-r border-border px-4 py-6 md:flex">
          <div className="flex items-center gap-3 px-1">
            <BrandMark />
            <div>
              <p className="text-sm font-medium tracking-tight">A06 Старт</p>
              <p className="text-xs text-muted-foreground">Qiyuan A06</p>
            </div>
          </div>
          <nav className="mt-8 flex flex-1 flex-col gap-1">
            {NAV.map((item) => {
              const active =
                item.to === "/"
                  ? pathname === "/"
                  : pathname.startsWith(item.to);
              return (
                <Link
                  key={item.to}
                  to={item.to}
                  className={cn(
                    "flex h-11 items-center gap-3 rounded-md px-3 text-sm transition-colors duration-150",
                    active
                      ? "bg-muted text-foreground"
                      : "text-muted-foreground hover:bg-muted/60 hover:text-foreground",
                  )}
                >
                  <item.icon className="size-4" />
                  {item.label}
                </Link>
              );
            })}
          </nav>
          <p className="px-3 text-xs text-faint">
            Профиль: {profileName}
          </p>
        </aside>

        <div className="flex min-w-0 flex-1 flex-col">
          <header className="flex h-14 items-center justify-between border-b border-border px-4 md:h-16 md:px-8">
            <div className="flex items-center gap-2 md:hidden">
              <BrandMark className="size-7" />
              <span className="text-sm font-medium">A06 Старт</span>
            </div>
            <p className="hidden text-sm text-muted-foreground md:block">
              Автозапуск приложений при включении ГУ
            </p>
            <span className="rounded-full border border-border px-2.5 py-1 text-xs font-medium tracking-wide text-muted-foreground uppercase">
              ACC
            </span>
          </header>

          <main className="flex-1 px-4 py-6 pb-24 md:px-8 md:pb-10">{children}</main>
        </div>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-border bg-background/95 md:hidden">
        <ul className="grid grid-cols-4">
          {NAV.map((item) => {
            const active =
              item.to === "/" ? pathname === "/" : pathname.startsWith(item.to);
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className={cn(
                    "flex h-16 flex-col items-center justify-center gap-1 text-xs",
                    active ? "text-foreground" : "text-muted-foreground",
                  )}
                >
                  <item.icon className="size-4" />
                  {item.label}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>
    </div>
  );
}
