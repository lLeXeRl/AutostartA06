import { cn } from "@/lib/utils";

export function BrandMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8 shrink-0", className)}
      aria-hidden="true"
    >
      <rect width="32" height="32" rx="8" fill="currentColor" className="text-card" />
      <rect x="7" y="9" width="2.5" height="14" rx="1" fill="currentColor" className="text-ok" />
      <polygon points="13,9 13,23 25.5,16" fill="currentColor" className="text-primary" />
    </svg>
  );
}
