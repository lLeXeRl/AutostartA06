import { resolveStep } from "@/lib/catalog";
import { enabledSteps } from "@/lib/store";
import type { Profile } from "@/lib/types";
import { cn } from "@/lib/utils";
import { CategoryIcon } from "./category-icon";

export function SequenceTimeline({
  profile,
  activeIndex = -1,
  compact = false,
}: {
  profile: Profile;
  activeIndex?: number;
  compact?: boolean;
}) {
  const steps = enabledSteps(profile);
  if (steps.length === 0) {
    return (
      <p className="text-sm text-muted-foreground">
        Сценарий пуст. Добавьте приложения во вкладке «Сценарий».
      </p>
    );
  }

  return (
    <ol className={cn("flex flex-col", compact ? "gap-2" : "gap-3")}>
      <li className="flex items-center gap-3">
        <span className="flex size-9 shrink-0 items-center justify-center rounded-md border border-border bg-muted text-xs font-medium tabular-nums text-muted-foreground">
          {profile.bootDelaySec}с
        </span>
        <div>
          <p className="text-sm font-medium">Ожидание готовности ГУ</p>
          {!compact && (
            <p className="text-xs text-muted-foreground">
              Лаунчер Changan поднимается не сразу. Не ставьте меньше 15 с.
            </p>
          )}
        </div>
      </li>
      {steps.map((step, index) => {
        const app = resolveStep(step);
        const active = index === activeIndex;
        return (
          <li key={step.id} className="flex items-center gap-3">
            <span
              className={cn(
                "flex size-9 shrink-0 items-center justify-center rounded-md border",
                active
                  ? "border-primary bg-primary text-primary-foreground"
                  : "border-border bg-card text-foreground",
              )}
            >
              <CategoryIcon category={app.category} className="size-4" />
            </span>
            <div className="min-w-0">
              <p className="truncate text-sm font-medium">{app.name}</p>
              <p className="truncate text-xs text-muted-foreground">
                {step.delaySec > 0 ? `пауза ${step.delaySec} с · ` : ""}
                {app.packageName}
              </p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
