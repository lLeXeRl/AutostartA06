import {
  Compass,
  MessageCircle,
  Music,
  Play,
  Wrench,
  type LucideIcon,
} from "lucide-react";
import type { AppCategory } from "@/lib/types";
import { cn } from "@/lib/utils";

const ICONS: Record<AppCategory, LucideIcon> = {
  nav: Compass,
  media: Music,
  video: Play,
  chat: MessageCircle,
  tool: Wrench,
};

export function CategoryIcon({
  category,
  className,
}: {
  category: AppCategory;
  className?: string;
}) {
  const Icon = ICONS[category];
  return <Icon className={cn("size-4", className)} />;
}
