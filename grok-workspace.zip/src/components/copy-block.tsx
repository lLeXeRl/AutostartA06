import { Check, Copy, Download } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { downloadText } from "@/lib/scripts";
import { Button } from "./ui/button";

export function CopyBlock({
  text,
  filename,
  label,
}: {
  text: string;
  filename?: string;
  label: string;
}) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(true);
      toast.success("Скопировано");
      window.setTimeout(() => setCopied(false), 1600);
    } catch {
      toast.error("Не удалось скопировать");
    }
  }

  return (
    <div className="overflow-hidden rounded-lg border border-border bg-background">
      <div className="flex items-center justify-between gap-2 border-b border-border px-3 py-2">
        <p className="text-xs font-medium text-muted-foreground">{label}</p>
        <div className="flex gap-1">
          {filename ? (
            <Button
              type="button"
              variant="ghost"
              size="sm"
              onClick={() => {
                downloadText(filename, text);
                toast.success("Файл скачан");
              }}
            >
              <Download />
              Файл
            </Button>
          ) : null}
          <Button type="button" variant="ghost" size="sm" onClick={() => void copy()}>
            {copied ? <Check /> : <Copy />}
            {copied ? "Есть" : "Копировать"}
          </Button>
        </div>
      </div>
      <pre className="max-h-80 overflow-auto p-3 font-mono text-xs leading-relaxed text-foreground whitespace-pre-wrap">
        {text}
      </pre>
    </div>
  );
}
