export type AppCategory = "nav" | "media" | "video" | "chat" | "tool";

export type LaunchMethod = "macrodroid" | "autostart" | "tasker";

export type CatalogApp = {
  id: string;
  name: string;
  packageName: string;
  category: AppCategory;
  blurb: string;
  splitOk: boolean;
};

export type LaunchStep = {
  id: string;
  appId: string;
  delaySec: number;
  enabled: boolean;
  customName?: string;
  customPackage?: string;
};

export type Profile = {
  id: string;
  name: string;
  bootDelaySec: number;
  method: LaunchMethod;
  steps: LaunchStep[];
};

export type SetupId =
  | "sdaSettings"
  | "devMode"
  | "wirelessAdb"
  | "caedc"
  | "helperInstalled"
  | "permissions"
  | "macroBuilt";
