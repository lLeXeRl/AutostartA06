import { enabledSteps } from "./store";
import { resolveStep } from "./catalog";
import type { LaunchMethod, Profile } from "./types";

export function launchCommand(packageName: string) {
  return `am start -a android.intent.action.MAIN -c android.intent.category.LAUNCHER -p ${packageName}`;
}

export function methodLabel(method: LaunchMethod) {
  if (method === "macrodroid") return "MacroDroid";
  if (method === "autostart") return "AutoStart";
  return "Tasker";
}

export function buildUnixScript(profile: Profile) {
  const steps = enabledSteps(profile);
  const lines = [
    "#!/bin/bash",
    `# A06 Старт — ${profile.name}`,
    "# Тестовый запуск сценария по ADB. Автозапуск после включения ГУ делает MacroDroid.",
    "# 1) adb pair IP:PORT CODE",
    "# 2) adb connect IP:PORT",
    "# 3) adb devices -l",
    "# 4) ./a06-start.sh <serial>",
    "set -euo pipefail",
    'SER="${1:-}"',
    'if [ -z "$SER" ]; then',
    '  echo "Usage: $0 <adb-serial>"',
    "  adb devices -l",
    "  exit 1",
    "fi",
    'echo "CAEDC bypass (до перезагрузки ГУ)…"',
    'adb -s "$SER" shell setprop vecentek.model 1',
    'adb -s "$SER" shell setprop debug.ro.debuggable 1',
    `echo "Пауза после «включения»: ${profile.bootDelaySec} с"`,
    `sleep ${profile.bootDelaySec}`,
  ];

  for (const step of steps) {
    const app = resolveStep(step);
    if (step.delaySec > 0) {
      lines.push(`echo "Пауза ${step.delaySec} с → ${app.name}"`);
      lines.push(`sleep ${step.delaySec}`);
    }
    lines.push(`echo "Запуск ${app.name} (${app.packageName})"`);
    lines.push(`adb -s "$SER" shell ${launchCommand(app.packageName)}`);
  }

  lines.push('echo "Готово. Если окно не вышло — проверьте, что пакет установлен: adb -s "$SER" shell pm path <package>"');
  return lines.join("\n") + "\n";
}

export function buildWindowsScript(profile: Profile) {
  const steps = enabledSteps(profile);
  const lines = [
    "@echo off",
    "chcp 65001 >nul",
    `rem A06 Старт — ${profile.name}`,
    "set SER=%1",
    'if "%SER%"=="" (',
    "  echo Usage: a06-start.bat ^<adb-serial^>",
    "  adb devices -l",
    "  exit /b 1",
    ")",
    "echo CAEDC bypass...",
    "adb -s %SER% shell setprop vecentek.model 1",
    "adb -s %SER% shell setprop debug.ro.debuggable 1",
    `echo Pause ${profile.bootDelaySec}s`,
    `timeout /t ${profile.bootDelaySec} /nobreak >nul`,
  ];

  for (const step of steps) {
    const app = resolveStep(step);
    if (step.delaySec > 0) {
      lines.push(`echo Pause ${step.delaySec}s - ${app.name}`);
      lines.push(`timeout /t ${step.delaySec} /nobreak >nul`);
    }
    lines.push(`echo Launch ${app.name}`);
    lines.push(`adb -s %SER% shell ${launchCommand(app.packageName)}`);
  }
  lines.push("echo Done.");
  return lines.join("\r\n") + "\r\n";
}

export function buildTestCommands(profile: Profile) {
  const steps = enabledSteps(profile);
  const lines = [
    `# Быстрая проверка без паузы на загрузку ГУ — ${profile.name}`,
    "adb devices -l",
    "adb shell setprop vecentek.model 1",
    "adb shell setprop debug.ro.debuggable 1",
  ];
  for (const step of steps) {
    const app = resolveStep(step);
    lines.push(`adb shell ${launchCommand(app.packageName)}  # ${app.name}`);
    if (step.delaySec > 0) lines.push(`# пауза ${step.delaySec} с перед этим приложением в реальном сценарии`);
  }
  return lines.join("\n") + "\n";
}

export function buildMacrodroidGuide(profile: Profile) {
  const steps = enabledSteps(profile);
  const actions: string[] = [];
  let n = 1;
  actions.push(`${n}. Действие → Ожидание / Wait: ${profile.bootDelaySec} секунд`);
  n += 1;
  for (const step of steps) {
    const app = resolveStep(step);
    if (step.delaySec > 0) {
      actions.push(`${n}. Действие → Ожидание / Wait: ${step.delaySec} секунд`);
      n += 1;
    }
    actions.push(
      `${n}. Действие → Приложения → Запустить приложение → ${app.name} (${app.packageName})`,
    );
    n += 1;
  }

  return [
    `Макрос: A06 Старт — ${profile.name}`,
    "",
    "Триггер",
    "1. Добавить триггер → Устройство → Загрузка устройства завершена",
    "   (Device Boot / Boot Completed)",
    "",
    "Действия по порядку",
    ...actions,
    "",
    "Ограничения",
    "Не ставьте. Макрос должен срабатывать на каждое включение ГУ.",
    "",
    "После сохранения",
    "• MacroDroid → настройки → исключить из оптимизации батареи",
    "• Разрешить автозапуск и работу в фоне",
    "• Проверка: в MacroDroid нажмите «Тест», не выключая машину",
    "• Боевая проверка: заглушить, подождать 30 с, включить зажигание",
    "",
    "Разделение экрана на A06",
    "Штатный split надёжнее руками: после запуска двух приложений — недавние → разделить.",
    "Не кладите в автозапуск больше трёх программ: лаунчер Changan часто убивает хвост.",
  ].join("\n");
}

export function buildAutostartGuide(profile: Profile) {
  const steps = enabledSteps(profile);
  const apps = steps.map((step) => resolveStep(step).name).join(", ");
  return [
    `AutoStart — ${profile.name}`,
    "",
    "1. Откройте AutoStart на ГУ.",
    "2. Добавьте приложения в том же порядке: " + (apps || "— список пуст —") + ".",
    `3. Задержку старта поставьте ${profile.bootDelaySec} с (общая, не пошаговая).`,
    "4. Включите Start on boot.",
    "5. Исключите AutoStart из оптимизации батареи.",
    "",
    "Минус метода: паузы между приложениями AutoStart обычно не умеет.",
    "Если нужен Навигатор, затем пауза, затем Музыка — берите MacroDroid.",
  ].join("\n");
}

export function buildTaskerGuide(profile: Profile) {
  const steps = enabledSteps(profile);
  const lines = [
    `Tasker — ${profile.name}`,
    "",
    "Профиль: Event → System → Device Boot",
    "Задача:",
    `1. Wait ${profile.bootDelaySec} seconds`,
  ];
  let n = 2;
  for (const step of steps) {
    const app = resolveStep(step);
    if (step.delaySec > 0) {
      lines.push(`${n}. Wait ${step.delaySec} seconds`);
      n += 1;
    }
    lines.push(`${n}. Launch App → ${app.name} (${app.packageName})`);
    n += 1;
  }
  lines.push("", "В Tasker отключите battery optimization и разрешите автозапуск.");
  return lines.join("\n");
}

export function downloadText(filename: string, text: string) {
  const blob = new Blob([text], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}
