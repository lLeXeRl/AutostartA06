import { create } from "zustand";
import { persist } from "zustand/middleware";
import { useEffect } from "react";
import type { LaunchMethod, LaunchStep, Profile, SetupId } from "./types";

const DEFAULT_PROFILE: Profile = {
  id: "preset-city",
  name: "Город",
  bootDelaySec: 25,
  method: "macrodroid",
  steps: [
    { id: "s-navi", appId: "yandex-navi", delaySec: 0, enabled: true },
    { id: "s-music", appId: "yandex-music", delaySec: 5, enabled: true },
  ],
};

export const PRESETS: { id: string; name: string; blurb: string; profile: Profile }[] = [
  {
    id: "city",
    name: "Город",
    blurb: "Навигатор и музыка — базовый ежедневный запуск.",
    profile: DEFAULT_PROFILE,
  },
  {
    id: "highway",
    name: "Трасса",
    blurb: "Дольше ждём готовности ГУ, затем навигатор, музыка и Telegram.",
    profile: {
      id: "preset-highway",
      name: "Трасса",
      bootDelaySec: 32,
      method: "macrodroid",
      steps: [
        { id: "h-navi", appId: "yandex-navi", delaySec: 0, enabled: true },
        { id: "h-music", appId: "yandex-music", delaySec: 6, enabled: true },
        { id: "h-tg", appId: "telegram", delaySec: 4, enabled: true },
      ],
    },
  },
  {
    id: "evening",
    name: "Вечер",
    blurb: "Карта слева, VK справа. Пауза подлиннее — видео тяжелее.",
    profile: {
      id: "preset-evening",
      name: "Вечер",
      bootDelaySec: 28,
      method: "macrodroid",
      steps: [
        { id: "e-navi", appId: "yandex-navi", delaySec: 0, enabled: true },
        { id: "e-vk", appId: "vk", delaySec: 8, enabled: true },
      ],
    },
  },
  {
    id: "nav-only",
    name: "Только навигатор",
    blurb: "Минимум. Если ГУ и так еле оживает.",
    profile: {
      id: "preset-nav",
      name: "Только навигатор",
      bootDelaySec: 20,
      method: "macrodroid",
      steps: [{ id: "n-navi", appId: "yandex-navi", delaySec: 0, enabled: true }],
    },
  },
];

type State = {
  profile: Profile;
  setup: Record<SetupId, boolean>;
  setName: (name: string) => void;
  setBootDelay: (sec: number) => void;
  setMethod: (method: LaunchMethod) => void;
  applyPreset: (id: string) => void;
  addStep: (step: Omit<LaunchStep, "id">) => void;
  updateStep: (id: string, patch: Partial<LaunchStep>) => void;
  removeStep: (id: string) => void;
  moveStep: (id: string, dir: -1 | 1) => void;
  toggleSetup: (id: SetupId) => void;
  resetAll: () => void;
};

const DEFAULT_SETUP: Record<SetupId, boolean> = {
  sdaSettings: false,
  devMode: false,
  wirelessAdb: false,
  caedc: false,
  helperInstalled: false,
  permissions: false,
  macroBuilt: false,
};

function cloneProfile(profile: Profile): Profile {
  return {
    ...profile,
    steps: profile.steps.map((step) => ({ ...step })),
  };
}

export const useLaunchStore = create<State>()(
  persist(
    (set, get) => ({
      profile: cloneProfile(DEFAULT_PROFILE),
      setup: { ...DEFAULT_SETUP },
      setName: (name) => set({ profile: { ...get().profile, name } }),
      setBootDelay: (bootDelaySec) =>
        set({ profile: { ...get().profile, bootDelaySec } }),
      setMethod: (method) => set({ profile: { ...get().profile, method } }),
      applyPreset: (id) => {
        const preset = PRESETS.find((item) => item.id === id);
        if (!preset) return;
        set({ profile: cloneProfile(preset.profile) });
      },
      addStep: (step) => {
        const id =
          typeof crypto !== "undefined" && crypto.randomUUID
            ? crypto.randomUUID()
            : `s-${Date.now()}`;
        set({
          profile: {
            ...get().profile,
            steps: [...get().profile.steps, { ...step, id }],
          },
        });
      },
      updateStep: (id, patch) =>
        set({
          profile: {
            ...get().profile,
            steps: get().profile.steps.map((step) =>
              step.id === id ? { ...step, ...patch } : step,
            ),
          },
        }),
      removeStep: (id) =>
        set({
          profile: {
            ...get().profile,
            steps: get().profile.steps.filter((step) => step.id !== id),
          },
        }),
      moveStep: (id, dir) => {
        const steps = [...get().profile.steps];
        const index = steps.findIndex((step) => step.id === id);
        const next = index + dir;
        if (index < 0 || next < 0 || next >= steps.length) return;
        const [item] = steps.splice(index, 1);
        steps.splice(next, 0, item);
        set({ profile: { ...get().profile, steps } });
      },
      toggleSetup: (id) =>
        set({ setup: { ...get().setup, [id]: !get().setup[id] } }),
      resetAll: () =>
        set({
          profile: cloneProfile(DEFAULT_PROFILE),
          setup: { ...DEFAULT_SETUP },
        }),
    }),
    { name: "a06-start-v1", skipHydration: true },
  ),
);

export function useRehydrateStore() {
  useEffect(() => {
    void useLaunchStore.persist.rehydrate();
  }, []);
}

export function enabledSteps(profile: Profile) {
  return profile.steps.filter((step) => step.enabled);
}

export function totalReadySec(profile: Profile) {
  return (
    profile.bootDelaySec +
    enabledSteps(profile).reduce((sum, step) => sum + step.delaySec, 0)
  );
}
