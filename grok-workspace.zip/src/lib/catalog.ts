import type { AppCategory, CatalogApp, LaunchStep } from "./types";

export const CATEGORY_LABEL: Record<AppCategory, string> = {
  nav: "Навигация",
  media: "Музыка",
  video: "Видео",
  chat: "Связь",
  tool: "Сервис",
};

export const CATALOG: CatalogApp[] = [
  {
    id: "yandex-navi",
    name: "Яндекс Навигатор",
    packageName: "ru.yandex.yandexnavi",
    category: "nav",
    blurb: "Основной сценарий на A06. Ставьте первым — карта должна открыться до музыки.",
    splitOk: true,
  },
  {
    id: "dgis",
    name: "2ГИС",
    packageName: "ru.dublgis.dgismobile",
    category: "nav",
    blurb: "Офлайн-карты и пробки. Хорошая замена, если Навигатор капризничает.",
    splitOk: true,
  },
  {
    id: "yandex-maps",
    name: "Яндекс Карты",
    packageName: "ru.yandex.yandexmaps",
    category: "nav",
    blurb: "Поиск мест и пробки. На ГУ обычно слабее Навигатора.",
    splitOk: true,
  },
  {
    id: "gmaps",
    name: "Google Maps",
    packageName: "com.google.android.apps.maps",
    category: "nav",
    blurb: "Нужны сервисы Google. На стоковом A06 часто отсутствуют.",
    splitOk: true,
  },
  {
    id: "waze",
    name: "Waze",
    packageName: "com.waze",
    category: "nav",
    blurb: "Народные пробки. Имеет смысл как второй навигатор.",
    splitOk: true,
  },
  {
    id: "yandex-music",
    name: "Яндекс Музыка",
    packageName: "ru.yandex.music",
    category: "media",
    blurb: "Типичная пара к навигатору. Запускайте с паузой 4–8 с.",
    splitOk: true,
  },
  {
    id: "spotify",
    name: "Spotify",
    packageName: "com.spotify.music",
    category: "media",
    blurb: "Нужен аккаунт и сеть. На ГУ лучше фиксировать качество заранее.",
    splitOk: true,
  },
  {
    id: "yt-music",
    name: "YouTube Music",
    packageName: "com.google.android.apps.youtube.music",
    category: "media",
    blurb: "Если на ГУ уже есть сервисы Google.",
    splitOk: true,
  },
  {
    id: "fermata",
    name: "Fermata Auto",
    packageName: "me.aap.fermata.auto",
    category: "media",
    blurb: "Локальный плеер без рекламы. Удобен в дальней дороге.",
    splitOk: true,
  },
  {
    id: "newpipe",
    name: "NewPipe",
    packageName: "org.schabi.newpipe",
    category: "video",
    blurb: "YouTube без официального клиента. Часто ставят через SDA/ADB.",
    splitOk: true,
  },
  {
    id: "youtube",
    name: "YouTube",
    packageName: "com.google.android.youtube",
    category: "video",
    blurb: "Официальный клиент. На A06 может требовать GMS.",
    splitOk: true,
  },
  {
    id: "vk",
    name: "VK",
    packageName: "com.vkontakte.android",
    category: "video",
    blurb: "VK Видео в разделении экрана с навигатором — частый вечерний сценарий.",
    splitOk: true,
  },
  {
    id: "ivi",
    name: "IVI",
    packageName: "ru.ivi.client",
    category: "video",
    blurb: "Фильмы на стоянке. В движение лучше не ставить первым.",
    splitOk: false,
  },
  {
    id: "telegram",
    name: "Telegram",
    packageName: "org.telegram.messenger",
    category: "chat",
    blurb: "Уведомления после навигатора. Не открывайте поверх карты без паузы.",
    splitOk: false,
  },
  {
    id: "whatsapp",
    name: "WhatsApp",
    packageName: "com.whatsapp",
    category: "chat",
    blurb: "Только если реально нужен в машине. Иначе мешает запуску.",
    splitOk: false,
  },
  {
    id: "ya-browser",
    name: "Яндекс Браузер",
    packageName: "com.yandex.browser",
    category: "tool",
    blurb: "Запасной способ открыть веб-сервисы, если APK не ставится.",
    splitOk: true,
  },
  {
    id: "ya-go",
    name: "Яндекс Go",
    packageName: "ru.yandex.taxi",
    category: "tool",
    blurb: "Такси и доставка. В автозапуск обычно не кладут.",
    splitOk: false,
  },
  {
    id: "chrome",
    name: "Chrome",
    packageName: "com.android.chrome",
    category: "tool",
    blurb: "На стоке A06 может отсутствовать.",
    splitOk: true,
  },
  {
    id: "macrodroid",
    name: "MacroDroid",
    packageName: "com.arlosoft.macrodroid",
    category: "tool",
    blurb: "Рекомендуемый движок автозапуска. Сам себя в сценарий не ставьте.",
    splitOk: false,
  },
  {
    id: "autostart",
    name: "AutoStart",
    packageName: "com.autostart",
    category: "tool",
    blurb: "Простой автозапуск без макросов. Меньше гибкости, чем MacroDroid.",
    splitOk: false,
  },
];

export function getCatalogApp(id: string): CatalogApp | undefined {
  return CATALOG.find((app) => app.id === id);
}

export function resolveStep(step: LaunchStep): {
  name: string;
  packageName: string;
  category: AppCategory;
  splitOk: boolean;
} {
  if (step.customPackage) {
    return {
      name: step.customName?.trim() || step.customPackage,
      packageName: step.customPackage.trim(),
      category: "tool",
      splitOk: true,
    };
  }
  const app = getCatalogApp(step.appId);
  if (app) {
    return {
      name: app.name,
      packageName: app.packageName,
      category: app.category,
      splitOk: app.splitOk,
    };
  }
  return {
    name: "Неизвестное приложение",
    packageName: step.appId,
    category: "tool",
    splitOk: false,
  };
}

export const CATEGORY_ORDER: AppCategory[] = ["nav", "media", "video", "chat", "tool"];
