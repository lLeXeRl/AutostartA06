import { createFileRoute, Link } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { SETUP_STEPS } from "@/lib/setup";
import { useLaunchStore } from "@/lib/store";
import { CopyBlock } from "@/components/copy-block";

export const Route = createFileRoute("/setup")({ component: SetupPage });

function SetupPage() {
  const setup = useLaunchStore((s) => s.setup);
  const toggleSetup = useLaunchStore((s) => s.toggleSetup);

  const done = SETUP_STEPS.filter((step) => setup[step.id]).length;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
          Установка
        </p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">
          Семь шагов на ГУ A06
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Прошивка вроде 1.6.0, портал SDA, Wi-Fi ADB и обход CAEDC. Отмечайте
          сделанное — прогресс останется в этом браузере.
        </p>
        <p className="mt-3 text-sm tabular-nums text-muted-foreground">
          {done} из {SETUP_STEPS.length}
        </p>
      </div>

      <ol className="flex flex-col gap-4">
        {SETUP_STEPS.map((step) => (
          <li key={step.id}>
            <Card>
              <CardContent className="flex flex-col gap-4">
                <div className="flex items-start gap-4">
                  <span className="flex size-9 shrink-0 items-center justify-center rounded-md border border-border bg-muted text-sm font-medium tabular-nums">
                    {step.n}
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h2 className="font-medium">{step.title}</h2>
                        <p className="mt-1 text-sm text-muted-foreground">{step.lead}</p>
                      </div>
                      <Switch
                        checked={setup[step.id]}
                        onCheckedChange={() => toggleSetup(step.id)}
                        aria-label={`${step.title}: сделано`}
                      />
                    </div>
                    <ul className="mt-3 flex flex-col gap-1.5 text-sm text-foreground">
                      {step.body.map((line) => (
                        <li key={line} className="pl-0">
                          {line}
                        </li>
                      ))}
                    </ul>
                    {step.warn ? (
                      <p className="mt-3 text-sm text-warn">{step.warn}</p>
                    ) : null}
                  </div>
                </div>
                {step.commands ? (
                  <CopyBlock
                    label="Команды"
                    text={step.commands.join("\n") + "\n"}
                  />
                ) : null}
              </CardContent>
            </Card>
          </li>
        ))}
      </ol>

      <div className="flex flex-wrap gap-2">
        <Button asChild>
          <Link to="/script">Открыть готовый скрипт</Link>
        </Button>
        <Button variant="outline" asChild>
          <Link to="/probe">Прогнать пробу</Link>
        </Button>
      </div>
    </div>
  );
}
