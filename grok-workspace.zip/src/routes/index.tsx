import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, Play, RotateCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { SequenceTimeline } from "@/components/sequence-timeline";
import { SETUP_STEPS } from "@/lib/setup";
import {
  enabledSteps,
  totalReadySec,
  useLaunchStore,
} from "@/lib/store";
import { methodLabel } from "@/lib/scripts";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const profile = useLaunchStore((s) => s.profile);
  const setup = useLaunchStore((s) => s.setup);
  const resetAll = useLaunchStore((s) => s.resetAll);

  const done = SETUP_STEPS.filter((step) => setup[step.id]).length;
  const ready = totalReadySec(profile);
  const apps = enabledSteps(profile).length;

  return (
    <div className="flex flex-col gap-6">
      <section className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
            Пульт
          </p>
          <h1 className="mt-1 text-3xl font-medium tracking-tight md:text-4xl">
            При включении ГУ
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            Соберите порядок запуска, поставьте MacroDroid на Qiyuan A06 и
            выгрузите готовый макрос. Само приложение на телефоне машину не
            управляет — оно готовит сценарий.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button asChild>
            <Link to="/probe">
              <Play />
              Проба запуска
            </Link>
          </Button>
          <Button variant="outline" asChild>
            <Link to="/sequence">
              Править сценарий
              <ArrowRight />
            </Link>
          </Button>
        </div>
      </section>

      <section className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader>
            <CardDescription>Готовность</CardDescription>
            <CardTitle className="text-3xl tabular-nums tracking-tight">
              {ready}
              <span className="ml-1 text-base font-medium text-muted-foreground">с</span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 text-sm text-muted-foreground">
            от ACC до последнего приложения
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>В сценарии</CardDescription>
            <CardTitle className="text-3xl tabular-nums tracking-tight">
              {apps}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0 text-sm text-muted-foreground">
            профиль «{profile.name}» · {methodLabel(profile.method)}
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardDescription>Установка на ГУ</CardDescription>
            <CardTitle className="text-3xl tabular-nums tracking-tight">
              {done}
              <span className="ml-1 text-base font-medium text-muted-foreground">
                / {SETUP_STEPS.length}
              </span>
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-0">
            <Badge tone={done === SETUP_STEPS.length ? "ok" : "muted"}>
              {done === SETUP_STEPS.length ? "Готово к бою" : "Есть шаги"}
            </Badge>
          </CardContent>
        </Card>
      </section>

      <section className="grid gap-4 lg:grid-cols-[1.2fr_0.8fr]">
        <Card>
          <CardHeader>
            <CardTitle>Следующий запуск</CardTitle>
            <CardDescription>
              Так поведут себя приложения после включения головного устройства.
            </CardDescription>
          </CardHeader>
          <CardContent>
            <SequenceTimeline profile={profile} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Чеклист A06</CardTitle>
            <CardDescription>Отмечайте шаги во вкладке «Установка».</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col gap-2">
            {SETUP_STEPS.map((step) => (
              <div key={step.id} className="flex items-center gap-3 text-sm">
                <span
                  className={
                    setup[step.id]
                      ? "size-2 rounded-full bg-ok"
                      : "size-2 rounded-full bg-border"
                  }
                />
                <span className={setup[step.id] ? "text-foreground" : "text-muted-foreground"}>
                  {step.title}
                </span>
              </div>
            ))}
            <Button variant="outline" className="mt-3" asChild>
              <Link to="/setup">Открыть установку</Link>
            </Button>
          </CardContent>
        </Card>
      </section>

      <div className="flex justify-end">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => {
            if (window.confirm("Сбросить сценарий и чеклист?")) resetAll();
          }}
        >
          <RotateCcw />
          Сбросить всё
        </Button>
      </div>
    </div>
  );
}
