import { createFileRoute } from "@tanstack/react-router";
import { ChevronDown, ChevronUp, Plus, Trash2 } from "lucide-react";
import { useMemo, useState } from "react";
import { CategoryIcon } from "@/components/category-icon";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { Switch } from "@/components/ui/switch";
import {
  CATALOG,
  CATEGORY_LABEL,
  CATEGORY_ORDER,
  resolveStep,
} from "@/lib/catalog";
import { PRESETS, useLaunchStore } from "@/lib/store";
import type { LaunchMethod } from "@/lib/types";
import { methodLabel } from "@/lib/scripts";

export const Route = createFileRoute("/sequence")({ component: SequencePage });

function SequencePage() {
  const profile = useLaunchStore((s) => s.profile);
  const setName = useLaunchStore((s) => s.setName);
  const setBootDelay = useLaunchStore((s) => s.setBootDelay);
  const setMethod = useLaunchStore((s) => s.setMethod);
  const applyPreset = useLaunchStore((s) => s.applyPreset);
  const addStep = useLaunchStore((s) => s.addStep);
  const updateStep = useLaunchStore((s) => s.updateStep);
  const removeStep = useLaunchStore((s) => s.removeStep);
  const moveStep = useLaunchStore((s) => s.moveStep);
  const [open, setOpen] = useState(false);

  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
          Сценарий
        </p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">Порядок запуска</h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Задержка после включения — общая. Пауза у приложения срабатывает перед
          ним. Навигатор всегда ставьте первым.
        </p>
      </div>

      <div className="flex flex-wrap gap-2">
        {PRESETS.map((preset) => (
          <Button
            key={preset.id}
            type="button"
            variant={profile.name === preset.name ? "default" : "outline"}
            size="sm"
            onClick={() => applyPreset(preset.id)}
          >
            {preset.name}
          </Button>
        ))}
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Профиль</CardTitle>
          <CardDescription>Имя попадёт в макрос и в имя файла скрипта.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-5 md:grid-cols-2">
          <div className="flex flex-col gap-2">
            <Label htmlFor="profile-name">Название</Label>
            <Input
              id="profile-name"
              value={profile.name}
              onChange={(e) => setName(e.target.value)}
              maxLength={40}
            />
          </div>
          <div className="flex flex-col gap-2">
            <Label>Движок на ГУ</Label>
            <div className="flex flex-wrap gap-2">
              {(["macrodroid", "autostart", "tasker"] as LaunchMethod[]).map((method) => (
                <Button
                  key={method}
                  type="button"
                  size="sm"
                  variant={profile.method === method ? "default" : "outline"}
                  onClick={() => setMethod(method)}
                >
                  {methodLabel(method)}
                </Button>
              ))}
            </div>
          </div>
          <div className="flex flex-col gap-2 md:col-span-2">
            <div className="flex items-center justify-between">
              <Label>Пауза после включения ГУ</Label>
              <span className="text-sm tabular-nums text-muted-foreground">
                {profile.bootDelaySec} с
              </span>
            </div>
            <Slider
              min={10}
              max={60}
              step={1}
              value={[profile.bootDelaySec]}
              onValueChange={(v) => setBootDelay(v[0] ?? 25)}
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center justify-between gap-3">
        <h2 className="text-base font-medium">Приложения</h2>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm">
              <Plus />
              Добавить
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Каталог для A06</DialogTitle>
              <DialogDescription>
                Пакеты проверены на типичных APK. Своё приложение — внизу.
              </DialogDescription>
            </DialogHeader>
            <AddAppForm
              existing={profile.steps.map((s) => s.appId)}
              onAdd={(payload) => {
                addStep(payload);
                setOpen(false);
              }}
            />
          </DialogContent>
        </Dialog>
      </div>

      <ul className="flex flex-col gap-3">
        {profile.steps.length === 0 ? (
          <Card>
            <CardContent className="text-sm text-muted-foreground">
              Список пуст. Добавьте хотя бы навигатор.
            </CardContent>
          </Card>
        ) : (
          profile.steps.map((step, index) => {
            const app = resolveStep(step);
            return (
              <li key={step.id}>
                <Card>
                  <CardContent className="flex flex-col gap-4">
                    <div className="flex items-start gap-3">
                      <span className="mt-0.5 flex size-10 shrink-0 items-center justify-center rounded-md border border-border bg-muted">
                        <CategoryIcon category={app.category} />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex flex-wrap items-center gap-2">
                          <p className="font-medium">{app.name}</p>
                          <Badge tone="line">{CATEGORY_LABEL[app.category]}</Badge>
                          {app.splitOk ? <Badge tone="muted">split ok</Badge> : null}
                        </div>
                        <p className="mt-0.5 truncate font-mono text-xs text-muted-foreground">
                          {app.packageName}
                        </p>
                      </div>
                      <Switch
                        checked={step.enabled}
                        onCheckedChange={(checked) =>
                          updateStep(step.id, { enabled: checked })
                        }
                        aria-label="В сценарии"
                      />
                    </div>
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center justify-between">
                        <Label>Пауза перед запуском</Label>
                        <span className="text-sm tabular-nums text-muted-foreground">
                          {step.delaySec} с
                        </span>
                      </div>
                      <Slider
                        min={0}
                        max={20}
                        step={1}
                        value={[step.delaySec]}
                        onValueChange={(v) =>
                          updateStep(step.id, { delaySec: v[0] ?? 0 })
                        }
                      />
                    </div>
                    <div className="flex flex-wrap gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        disabled={index === 0}
                        onClick={() => moveStep(step.id, -1)}
                      >
                        <ChevronUp />
                        Выше
                      </Button>
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        disabled={index === profile.steps.length - 1}
                        onClick={() => moveStep(step.id, 1)}
                      >
                        <ChevronDown />
                        Ниже
                      </Button>
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        className="ml-auto text-destructive"
                        onClick={() => removeStep(step.id)}
                      >
                        <Trash2 />
                        Убрать
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </li>
            );
          })
        )}
      </ul>
    </div>
  );
}

function AddAppForm({
  existing,
  onAdd,
}: {
  existing: string[];
  onAdd: (step: {
    appId: string;
    delaySec: number;
    enabled: boolean;
    customName?: string;
    customPackage?: string;
  }) => void;
}) {
  const [query, setQuery] = useState("");
  const [customName, setCustomName] = useState("");
  const [customPackage, setCustomPackage] = useState("");

  const grouped = useMemo(() => {
    const q = query.trim().toLowerCase();
    return CATEGORY_ORDER.map((category) => ({
      category,
      apps: CATALOG.filter((app) => {
        if (app.category !== category) return false;
        if (!q) return true;
        return (
          app.name.toLowerCase().includes(q) ||
          app.packageName.toLowerCase().includes(q)
        );
      }),
    })).filter((g) => g.apps.length > 0);
  }, [query]);

  return (
    <div className="flex flex-col gap-4">
      <Input
        placeholder="Поиск по имени или пакету"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />
      <div className="flex max-h-72 flex-col gap-4 overflow-y-auto pr-1">
        {grouped.map((group) => (
          <div key={group.category}>
            <p className="mb-2 text-xs font-medium tracking-wide text-muted-foreground uppercase">
              {CATEGORY_LABEL[group.category]}
            </p>
            <ul className="flex flex-col gap-1">
              {group.apps.map((app) => {
                const used = existing.includes(app.id);
                return (
                  <li key={app.id}>
                    <button
                      type="button"
                      disabled={used}
                      onClick={() =>
                        onAdd({
                          appId: app.id,
                          delaySec: app.category === "nav" ? 0 : 5,
                          enabled: true,
                        })
                      }
                      className="flex w-full items-start gap-3 rounded-md px-2 py-2 text-left hover:bg-muted disabled:opacity-40"
                    >
                      <CategoryIcon category={app.category} className="mt-0.5" />
                      <span className="min-w-0">
                        <span className="block text-sm font-medium">{app.name}</span>
                        <span className="block text-xs text-muted-foreground">
                          {used ? "Уже в сценарии · " : ""}
                          {app.blurb}
                        </span>
                      </span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        ))}
      </div>
      <div className="grid gap-2 rounded-md border border-border p-3">
        <p className="text-sm font-medium">Свой пакет</p>
        <Input
          placeholder="Имя, как на ГУ"
          value={customName}
          onChange={(e) => setCustomName(e.target.value)}
        />
        <Input
          placeholder="com.example.app"
          value={customPackage}
          onChange={(e) => setCustomPackage(e.target.value)}
          className="font-mono"
        />
        <Button
          type="button"
          variant="outline"
          disabled={!customPackage.trim()}
          onClick={() =>
            onAdd({
              appId: `custom:${customPackage.trim()}`,
              delaySec: 5,
              enabled: true,
              customName: customName.trim() || customPackage.trim(),
              customPackage: customPackage.trim(),
            })
          }
        >
          Добавить пакет
        </Button>
      </div>
    </div>
  );
}
