import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { CopyBlock } from "@/components/copy-block";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  buildAutostartGuide,
  buildMacrodroidGuide,
  buildTaskerGuide,
  buildTestCommands,
  buildUnixScript,
  buildWindowsScript,
  methodLabel,
} from "@/lib/scripts";
import { enabledSteps, useLaunchStore } from "@/lib/store";

export const Route = createFileRoute("/script")({ component: ScriptPage });

type Tab = "guide" | "unix" | "win" | "test";

function ScriptPage() {
  const profile = useLaunchStore((s) => s.profile);
  const [tab, setTab] = useState<Tab>("guide");

  const slug = profile.name
    .toLowerCase()
    .replace(/[^a-z0-9а-яё]+/gi, "-")
    .replace(/^-|-$/g, "") || "profile";

  const guide =
    profile.method === "autostart"
      ? buildAutostartGuide(profile)
      : profile.method === "tasker"
        ? buildTaskerGuide(profile)
        : buildMacrodroidGuide(profile);

  const empty = enabledSteps(profile).length === 0;

  return (
    <div className="flex flex-col gap-6">
      <div>
        <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
          Скрипт
        </p>
        <h1 className="mt-1 text-3xl font-medium tracking-tight">
          Выгрузка «{profile.name}»
        </h1>
        <p className="mt-2 max-w-2xl text-sm text-muted-foreground">
          Макрос собирается руками на ГУ по инструкции. ADB-скрипт — чтобы
          проверить запуск сейчас, не дожидаясь следующего включения.
        </p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>{methodLabel(profile.method)}</CardTitle>
          <CardDescription>
            Движок меняется в сценарии. Сейчас активен {methodLabel(profile.method)}.
          </CardDescription>
        </CardHeader>
        <CardContent className="flex flex-wrap gap-2">
          {(
            [
              ["guide", "Инструкция"],
              ["unix", "ADB · Mac/Linux"],
              ["win", "ADB · Windows"],
              ["test", "Проверка сразу"],
            ] as const
          ).map(([id, label]) => (
            <Button
              key={id}
              type="button"
              size="sm"
              variant={tab === id ? "default" : "outline"}
              onClick={() => setTab(id)}
            >
              {label}
            </Button>
          ))}
        </CardContent>
      </Card>

      {empty ? (
        <p className="text-sm text-muted-foreground">
          В сценарии нет включённых приложений — добавлять нечего.
        </p>
      ) : null}

      {tab === "guide" ? (
        <CopyBlock label={`Инструкция · ${methodLabel(profile.method)}`} text={guide} />
      ) : null}
      {tab === "unix" ? (
        <CopyBlock
          label="a06-start.sh"
          filename={`a06-start-${slug}.sh`}
          text={buildUnixScript(profile)}
        />
      ) : null}
      {tab === "win" ? (
        <CopyBlock
          label="a06-start.bat"
          filename={`a06-start-${slug}.bat`}
          text={buildWindowsScript(profile)}
        />
      ) : null}
      {tab === "test" ? (
        <CopyBlock
          label="Команды без длинной паузы"
          text={buildTestCommands(profile)}
        />
      ) : null}

      <p className="text-xs text-faint">
        Установка APK и setprop — на ваш риск. CAEDC сбрасывается после ребута ГУ.
        Не отключайте системные пакеты Changan.
      </p>
    </div>
  );
}
