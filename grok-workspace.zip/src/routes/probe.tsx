import { createFileRoute, Link } from "@tanstack/react-router";
import { Pause, Play, RotateCcw } from "lucide-react";
import { useEffect, useMemo, useRef, useState } from "react";
import { CategoryIcon } from "@/components/category-icon";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { resolveStep } from "@/lib/catalog";
import { enabledSteps, totalReadySec, useLaunchStore } from "@/lib/store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/probe")({ component: ProbePage });

type Machine = "idle" | "running" | "ready";

type Event = {
  at: number;
  label: string;
};

const SIM_SPEED = 8;

function ProbePage() {
  const profile = useLaunchStore((s) => s.profile);
  const steps = enabledSteps(profile);
  const total = totalReadySec(profile);

  const events = useMemo<Event[]>(() => {
    const list: Event[] = [
      { at: 0, label: "ACC ON" },
      { at: 2, label: "Загрузка лаунчера" },
      { at: profile.bootDelaySec, label: "ГУ готово" },
    ];
    let t = profile.bootDelaySec;
    for (const step of steps) {
      t += step.delaySec;
      list.push({ at: t, label: resolveStep(step).name });
    }
    return list;
  }, [profile.bootDelaySec, steps]);

  const [machine, setMachine] = useState<Machine>("idle");
  const [elapsed, setElapsed] = useState(0);
  const [paused, setPaused] = useState(false);
  const elapsedRef = useRef(0);

  useEffect(() => {
    if (machine !== "running" || paused) return;
    const id = window.setInterval(() => {
      elapsedRef.current += 0.1 * SIM_SPEED;
      const sec = elapsedRef.current;
      if (sec >= total + 1.2) {
        setMachine("ready");
        setElapsed(total);
        elapsedRef.current = total;
        return;
      }
      setElapsed(sec);
    }, 100);
    return () => window.clearInterval(id);
  }, [machine, paused, total]);

  function start() {
    elapsedRef.current = 0;
    setElapsed(0);
    setPaused(false);
    setMachine("running");
  }

  function reset() {
    elapsedRef.current = 0;
    setElapsed(0);
    setPaused(false);
    setMachine("idle");
  }

  const view =
    machine === "idle"
      ? "idle"
      : machine === "ready"
        ? "ready"
        : elapsed < 1.2
          ? "acc"
          : elapsed < profile.bootDelaySec
            ? "boot"
            : "run";

  let activeAppIndex = -1;
  if (view === "run" || view === "ready") {
    let t = profile.bootDelaySec;
    for (let i = 0; i < steps.length; i += 1) {
      t += steps[i]!.delaySec;
      if (elapsed >= t) activeAppIndex = i;
    }
  }
  const shownApp = activeAppIndex >= 0 ? resolveStep(steps[activeAppIndex]!) : null;
  const progress = total === 0 ? 0 : Math.min(1, elapsed / Math.max(total, 0.01));

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">
            Проба
          </p>
          <h1 className="mt-1 text-3xl font-medium tracking-tight">
            Включение ГУ
          </h1>
          <p className="mt-2 max-w-xl text-sm text-muted-foreground">
            Это ускоренная модель сценария (×8), не живой ADB. Нужна, чтобы
            поймать слишком короткие паузы до поездки.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          {machine === "idle" || machine === "ready" ? (
            <Button onClick={start}>
              <Play />
              {machine === "ready" ? "Ещё раз" : "Зажигание"}
            </Button>
          ) : (
            <Button variant="outline" onClick={() => setPaused((v) => !v)}>
              {paused ? <Play /> : <Pause />}
              {paused ? "Дальше" : "Пауза"}
            </Button>
          )}
          <Button variant="ghost" onClick={reset}>
            <RotateCcw />
            Сброс
          </Button>
        </div>
      </div>

      <div className="mx-auto w-full max-w-3xl">
        <div className="rounded-2xl border border-border bg-card p-3 md:p-4">
          <div className="flex items-center justify-between px-2 pb-3 text-xs tracking-wide text-muted-foreground uppercase">
            <span>Qiyuan A06 · 15.6</span>
            <span className={cn(view === "idle" ? "text-faint" : "text-ok")}>
              {view === "idle" ? "OFF" : view === "ready" ? "READY" : "ACC"}
            </span>
          </div>
          <div className="relative aspect-video overflow-hidden rounded-lg border border-border bg-background">
            <div className="absolute inset-0 flex flex-col items-center justify-center gap-3 p-6 text-center">
              {view === "idle" ? (
                <>
                  <p className="text-sm text-muted-foreground">ГУ выключено</p>
                  <p className="text-xs text-faint">Нажмите «Зажигание»</p>
                </>
              ) : null}
              {view === "acc" ? (
                <p className="text-lg font-medium tracking-tight">ACC</p>
              ) : null}
              {view === "boot" ? (
                <>
                  <p className="text-sm text-muted-foreground">Загрузка системы</p>
                  <p className="font-mono text-2xl tabular-nums">
                    {Math.max(0, Math.ceil(profile.bootDelaySec - elapsed))}с
                  </p>
                </>
              ) : null}
              {view === "run" && shownApp ? (
                <>
                  <span className="flex size-14 items-center justify-center rounded-md border border-border bg-card">
                    <CategoryIcon category={shownApp.category} className="size-6" />
                  </span>
                  <p className="text-lg font-medium tracking-tight">{shownApp.name}</p>
                  <p className="font-mono text-xs text-muted-foreground">
                    {shownApp.packageName}
                  </p>
                </>
              ) : null}
              {view === "ready" ? (
                <>
                  <p className="text-lg font-medium tracking-tight">Сценарий выполнен</p>
                  <p className="text-sm text-muted-foreground">
                    {steps.length} прил. за {total} с
                  </p>
                </>
              ) : null}
            </div>
            <div className="absolute inset-x-0 bottom-0 h-1 bg-muted">
              <div
                className="h-full bg-primary"
                style={{ width: `${progress * 100}%` }}
              />
            </div>
          </div>
        </div>
      </div>

      <Card>
        <CardContent className="flex flex-col gap-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-medium">Таймлайн</p>
            <p className="font-mono text-sm tabular-nums text-muted-foreground">
              {elapsed.toFixed(1)} / {total} с
            </p>
          </div>
          <ol className="flex flex-col gap-2">
            {events.map((event) => {
              const reached = elapsed >= event.at && machine !== "idle";
              return (
                <li
                  key={`${event.at}-${event.label}`}
                  className={cn(
                    "flex items-center justify-between gap-3 text-sm",
                    reached ? "text-foreground" : "text-muted-foreground",
                  )}
                >
                  <span>{event.label}</span>
                  <span className="font-mono text-xs tabular-nums">{event.at}с</span>
                </li>
              );
            })}
          </ol>
        </CardContent>
      </Card>

      <Button variant="outline" asChild className="self-start">
        <Link to="/sequence">Вернуться к сценарию</Link>
      </Button>
    </div>
  );
}
